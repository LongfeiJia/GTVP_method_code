function h=distanceCost(a,b)
[i j]=size(a);
for w=1:i
    h(w,1)=((a(w,1)-b(1))^2+(a(w,2)-b(2))^2)^0.5;
end
    
    
   % h = sqrt(sum((a-b).^2, 2));