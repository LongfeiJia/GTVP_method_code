clc;clear all;

map=im2bw(imread('98.png'));


source=[315 180]; % source position in Y, X format570-150=420
goal=[315 690]; % goal position in Y, X format
stepsize =30;  % size of each step of the RRT
threshold = 20; % nodes closer than this threshold are taken as almost the same

maxFailedAttempts = 1000;
display = true; % display of RRT
if ~feasiblePoint(source,map), error('source lies on an obstacle or outside map'); end
if ~feasiblePoint(goal,map), error('goal lies on an obstacle or outside map'); end
if display,imshow(map); end
 

 
RRTree = double([source -1 0]); % RRT rooted at the source, representation node and parent index
failedAttempts = 0;
counter = 0;
pathFound = false;
 tic;  % tic-toc: Functions for Elapsed Time
while failedAttempts <= maxFailedAttempts  % loop to grow RRTs
    if rand < 0.9
        sample = rand(1,2) .* size(map);   % random sample
    else
        sample = goal; % sample taken as goal to bias tree generation to goal
    end

    [A, I] = min( distanceCost(RRTree(:,1:2),sample) ,[],1); % find the minimum value of each column
    closestNode = RRTree(I(1),1:2);
     
    theta = atan2(sample(1)-closestNode(1),sample(2)-closestNode(2));  % direction to extend sample to produce new node
    newPoint = double(int32(closestNode(1:2) + stepsize * [sin(theta)  cos(theta)]));
    if ~checkPath(closestNode(1:2), newPoint, map) % if extension of closest node in tree to the new point is feasible
        failedAttempts = failedAttempts + 1;
        continue;
    end
    if distanceCost(newPoint,goal) < stepsize, pathFound = true; break; end % goal reached
     
    [A, I2] = min( distanceCost(RRTree(:,1:2),newPoint) ,[],1); % check if new node is not already pre-existing in the tree
    if distanceCost(newPoint,RRTree(I2(1),1:2)) < threshold, failedAttempts = failedAttempts + 1; continue; end
     %�뾶��Χ��
[ajl bjl]=size(RRTree);

for ijl=1:ajl
     if (checkPath(RRTree(ijl,1:2), newPoint, map))
         if ((RRTree(I(1),4)+distanceCost(newPoint,RRTree(I(1),1:2)))>RRTree(ijl,4)+distanceCost(newPoint,RRTree(ijl,1:2)))
              I(1)=ijl; closestNode=RRTree(I(1),1:2);
              line([RRTree(ijl,2);newPoint(2)],[RRTree(ijl,1);newPoint(1)], 'Color',[0.3 0.8 0.8],'LineWidth',1);hold on;
         end
     end
end  

for ijl=1:ajl
     if (distanceCost(newPoint,RRTree(ijl,1:2)) <2.5*stepsize)
        prev1 = I(1);
while prev1 > 0
    if checkPath(RRTree(prev1,1:2),RRTree(ijl,1:2), map)& (prev1~=ijl)&(RRTree(ijl,4)>RRTree(prev1,4)+distanceCost(RRTree(ijl,1:2),RRTree(prev1,1:2))) %%!!!!!!!!!!!!!!!jiaodu
            RRTree(ijl,4)=RRTree(prev1,4)+distanceCost(RRTree(ijl,1:2),RRTree(prev1,1:2));
            RRTree(ijl,3)=prev1; 
           line([RRTree(ijl,2);RRTree(prev1,2)],[RRTree(ijl,1);RRTree(prev1,1)], 'Color',[1 0.7 0.3],'LineWidth',1);hold on;
    end
    prev1 = RRTree(prev1,3);
end        
     end
end  
    
ddd=distanceCost(newPoint,RRTree(I(1),1:2));
    RRTree = [RRTree; newPoint I(1) ddd+RRTree(I(1),4)]; % add node
    failedAttempts = 0;
    if display, line([closestNode(2);newPoint(2)],[closestNode(1);newPoint(1)]);hold on;counter = counter + 1; M(counter) = getframe; end % Capture movie frame
end
toc
if display && pathFound, line([closestNode(2);newPoint(2)],[closestNode(1);newPoint(1)]);hold on;line([newPoint(2);goal(2)],[newPoint(1);goal(1)]);hold on; counter = counter+1;M(counter) = getframe; end
 
if display, disp('click/press any key'); waitforbuttonpress; end
if ~pathFound, error('no path found. maximum attempts reached'); end
 
% retrieve path from parent information
path = [newPoint;goal];
prev = I(1);
while prev > 0
    path = [RRTree(prev,1:2); path];
    prev = RRTree(prev,3);
end
 
pathLength = 0;
for i=1:length(path)-1, pathLength = pathLength + distanceCost(path(i,1:2),path(i+1,1:2)); end % calculate path length
pathLength
line(path(:,2),path(:,1), 'Color',[1 0 0],'LineWidth',2);hold on;

glh=5;
line([source(2)-glh;source(2)+glh],[source(1);source(1)], 'Color',[0 1 0],'LineWidth',2);hold on;
line([source(2);source(2)],[source(1)-glh;source(1)+glh], 'Color',[0 1 0],'LineWidth',2);hold on;

line([goal(2)-glh;goal(2)+glh],[goal(1);goal(1)], 'Color',[0 1 0],'LineWidth',2);hold on;
line([goal(2);goal(2)],[goal(1)-glh;goal(1)+glh], 'Color',[0 1 0],'LineWidth',2);hold on;