%%
%���10s    �ϰ������е�۵��������仯����

clc;clear all;
axis([0 40 -20 20]);theAxes=axis;
start_size=15;line_size=1.5;
L_jxb=[7.6,7.6,7.6,7.6,7.6,4,4,6];

chang_circle=5;gao_circle=-8;%O
gao_tri=30;chang_tri=4;%^
chang_rec=20;gao_rec=12;%������
chang_star=30;gao_star=-10;%�����
gao_obs5=5;chang_obs5=6;%L

for i=1:1001
    %set(gca,'FontSize',16);set(gca,'FontName','Times New Roman');
    t(i)=(i-1)*0.01;
    l_tri=4;
    D_chang_circle(i)=5+9*sin(pi*t(i)/20);    D_gao_circle(i)=-10*cos(pi*t(i)/20)-2;%O
    D_gao_tri(i)=30+0.1*t(i);D_chang_tri(i)=13-1*t(i);%^
    D_chang_rec(i)=20+4*sin(pi*t(i)/5);D_gao_rec(i)=4+4*cos(pi*t(i)/5)+4*cos(pi*t(i)/20);%������
    D_chang_star(i)=35-t(i);D_gao_star(i)=-18+1.5*t(i);%�����
    D_gao_obs5(i)=5+sin(pi*t(i)/3);    D_chang_obs5(i)=11-t(i);%L
    ang_tri(i)=pi*t(i)/20;
end

 
n=101;

tic;
for j=1:n;
nn=(j-1)*1+900;% ���10s�Ĺ���  %��Ӧʱ��
%ww=;        %��Ӧ�ڼ����ؼ���
[X_bez,Y_bez,dist]=juli2(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri);
DDD(:,j)=dist;
end
toc



tic;
for j=1:n;
nn=(j-1)*1+900;% ���10s�Ĺ���  %��Ӧʱ��
[X_bez,Y_bez,dist]=juli2(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri);
DDD(:,j)=dist;
end
toc





%%
    plot(DDD(4,:).*50,'--','color',[0.1,0.1,0.9],'LineWidth',2);hold on;
    plot(DDD(5,:).*50,'--','color',[0.1,0.9,0.1],'LineWidth',2);hold on;
    plot(DDD(6,:).*50,'--','color',[0.9,0.1,0.1],'LineWidth',2);hold on;
    plot(DDD(7,:).*50,'--','color',[0.5,0.5,0.5],'LineWidth',2);hold on;
    plot(DDD(8,:).*50,'--','color',[0.1,0.9,0.9],'LineWidth',2);hold on;
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
axis([1 101 0 350]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
% set(gca,'Ytick',[1:0.2:2]);set(gca,'YtickLabel',{'50','60','70','80','90','100'});
xlabel('\itt\rm(s)');
ylabel('\itd\rm(mm)');
legend('\itd\rm_4','\itd\rm_5','\itd\rm_6','\itd\rm_7','\itd\rm_8');


%%
    plot(DDD(1,:).*50,'--','color','r','LineWidth',2);hold on;
    plot(DDD(2,:).*50,'--','color','b','LineWidth',2);hold on;
    plot(DDD(3,:).*50,'--','color',[0.7,0.3,0.5],'LineWidth',2);hold on;
    plot(DDD(9,:).*50,'--','color','k','LineWidth',2);hold on;
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
 axis([1 101 0 1200]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
xlabel('\itt\rm(s)');
ylabel('\itd\rm(mm)');
legend('\itd\rm_1','\itd\rm_2','\itd\rm_3','\itd\rm_9');


%%
%     plot(DDD(1,:).*50,'>','color','k','LineWidth',1);hold on;
    plot(DDD(2,:).*50,'>','color','k','LineWidth',1);hold on;
    plot(DDD(3,:).*50,'o','color','k','LineWidth',1);hold on;
    plot(DDD(4,:).*50,'-','color','k','LineWidth',1);hold on;
    plot(DDD(5,:).*50,':','color','k','LineWidth',1);hold on;
    plot(DDD(6,:).*50,'--','color','k','LineWidth',1);hold on;
    plot(DDD(7,:).*50,'x','color','k','LineWidth',1);hold on;
    plot(DDD(8,:).*50,'.','color','k','LineWidth',1);hold on;
    plot(DDD(9,:).*50,'+','color','k','LineWidth',1);hold on;
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
axis([1 101 0 700]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
xlabel('\itt\rm(s)');
ylabel('\itd\rm(mm)');
legend('\itd\rm_2','\itd\rm_3','\itd\rm_4','\itd\rm_5','\itd\rm_6','\itd\rm_7','\itd\rm_8','\itd\rm_9');

%%
      k=2;
    plot(DDD(2,:).*50,'-.','color',[163,73,164]/255,'LineWidth',k);hold on;
    plot(DDD(3,:).*50,'-.','color',[0,162,232]/255,'LineWidth',k);hold on;
    plot(DDD(4,:).*50,'-','color',[255,127,39]/255,'LineWidth',k);hold on;
    plot(DDD(5,:).*50,'-','color',[136,0,21]/255,'LineWidth',k);hold on;
    plot(DDD(6,:).*50,'--','color',[0.5,0.5,0.5],'LineWidth',k);hold on;
    plot(DDD(7,:).*50,'--','color',[0,1,1],'LineWidth',k);hold on;
    plot(DDD(8,:).*50,':','color',[1,0,1],'LineWidth',k);hold on;
    plot(DDD(9,:).*50,':','color',[0,1,0],'LineWidth',k);hold on;
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
axis([1 101 0 700]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
xlabel('\itt\rm(s)');
ylabel('\itd_i\rm(mm)');
legend('\itd\rm_1','\itd\rm_2','\itd\rm_3','\itd\rm_4','\itd\rm_5','\itd\rm_6','\itd\rm_7','\itd\rm_8');


