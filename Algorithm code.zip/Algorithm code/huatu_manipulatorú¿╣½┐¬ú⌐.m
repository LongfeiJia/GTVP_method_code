function huatu_manipulator(nn,X_bez,Y_bez,L_jxb)

%����е��  7.6 X 5,  4,  4,  6
x_jxb(9)=(nn-1).*40/1000;
% y_jxb(9)=0;

[a,b]=size(X_bez);
e=1000;N=1;
for j=1:b
    if e>abs(X_bez(j)-x_jxb(9))
        N=j;
        e=abs(X_bez(j)-x_jxb(9));
    end
end
y_jxb(9)=Y_bez(N);


r_0=1;
aplha=0:pi/40:2*pi;
x_0=r_0*cos(aplha);
y_0=r_0*sin(aplha);
plot(x_0+x_jxb(9),y_0+y_jxb(9),'color','k');hold on;
fill(x_0+x_jxb(9),y_0+y_jxb(9),[0.1 0.9 0.1]);hold on;






for jxbi=8:-1:1
    if x_jxb(jxbi+1)-L_jxb(jxbi)>0
    [x_jxb(jxbi),y_jxb(jxbi)]=fa_fen_2(x_jxb(jxbi+1),y_jxb(jxbi+1),L_jxb(jxbi),X_bez,Y_bez);
    link(x_jxb(jxbi),y_jxb(jxbi),x_jxb(jxbi+1),y_jxb(jxbi+1));hold on;
    else
        x_jxb(jxbi)=x_jxb(jxbi+1)-L_jxb(jxbi);
        y_jxb(jxbi)=0;
        link(x_jxb(jxbi),y_jxb(jxbi),x_jxb(jxbi+1),y_jxb(jxbi+1));hold on;
    end
end
 
% else
% %����е��  7.6 X 5,  4,  4,  6
% %ĩ��λ��Ϊ��(nn-1).*40/1000��0��
% x_jxb(9)=(nn-1).*40/1000;y_jxb(9)=0;
% for jxbi=8:-1:1
%     x_jxb(jxbi)=x_jxb(jxbi+1)-L_jxb(jxbi);
%     y_jxb(jxbi)=0;
%     link(x_jxb(jxbi),y_jxb(jxbi),x_jxb(jxbi+1),y_jxb(jxbi+1));hold on;
% end
%    
