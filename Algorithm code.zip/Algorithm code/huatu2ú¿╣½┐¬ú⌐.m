function huatu2(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri)


l_tri=4;


r_0=1;
aplha=0:pi/40:2*pi;
x_0=r_0*cos(aplha);
y_0=r_0*sin(aplha);


chang_circle=D_chang_circle(nn);gao_circle=D_gao_circle(nn);%O
gao_tri=D_gao_tri(nn);chang_tri=D_chang_tri(nn);%^
chang_rec=D_chang_rec(nn);gao_rec=D_gao_rec(nn);%������
chang_star=D_chang_star(nn);gao_star=D_gao_star(nn);%�����
gao_obs5=D_gao_obs5(nn);chang_obs5=D_chang_obs5(nn);%L


%obs1ΪԲ
r_circle=2;

P_circle=[chang_circle gao_circle;
    chang_circle+r_circle-r_circle*sin(pi/6) gao_circle+r_circle*cos(pi/6);
    chang_circle+r_circle+r_circle*sin(pi/6) gao_circle+r_circle*cos(pi/6);
    chang_circle+2*r_circle gao_circle;
    chang_circle+r_circle+r_circle*sin(pi/6) gao_circle-r_circle*cos(pi/6);
    chang_circle+r_circle-r_circle*sin(pi/6) gao_circle-r_circle*cos(pi/6);];
%��obs1_Բ
aplha=0:pi/40:2*pi;
x_circle=r_circle*cos(aplha)+chang_circle+r_circle;
y_circle=r_circle*sin(aplha)+gao_circle;
plot(x_circle,y_circle,'color','k');hold on;
fill(x_circle,y_circle,[0.8 0.1 0.1]);hold on;

%obs2Ϊ������

%��obs2
P1_tri=[gao_tri,chang_tri];
P2_tri=[gao_tri+l_tri,chang_tri];
P3_tri=[gao_tri+0.5*l_tri,chang_tri+(3^.5/2)*l_tri];
x_tri=[P1_tri(1),P2_tri(1),P3_tri(1),P1_tri(1)];
y_tri=[P1_tri(2),P2_tri(2),P3_tri(2),P1_tri(2)];

x_tri2=[P1_tri(1)-2*3^.5,P2_tri(1)+2*3^.5,P3_tri(1),P1_tri(1)-2*3^.5];
y_tri2=[P1_tri(2)-2,P2_tri(2)-2,P3_tri(2)+4,P1_tri(2)-2];

ang=ang_tri(nn);
Rz=[cos(ang) -sin(ang);sin(ang) cos(ang);];
for w=1:4
    XY(:,w)=Rz*[x_tri(w)-(gao_tri+0.5*l_tri);y_tri(w)-(chang_tri+(1/(2*3^.5))*l_tri)];
    XY2(:,w)=Rz*[x_tri2(w)-(gao_tri+0.5*l_tri);y_tri2(w)-(chang_tri+(1/(2*3^.5))*l_tri)];
end
plot(XY(1,:)+(gao_tri+0.5*l_tri),XY(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),'color','k');hold on;
fill(XY(1,:)+(gao_tri+0.5*l_tri),XY(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),[0.3 0.5 0.1]);hold on;

%obs3Ϊ������
chang=4;gao=6;
P_rec=[chang_rec gao_rec;
    chang_rec gao_rec+gao;
    chang_rec+chang gao_rec+gao;
    chang_rec+chang gao_rec];
%��obs3
for i=1:3
    plot([P_rec(i,1),P_rec(i+1,1)],[P_rec(i,2),P_rec(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_rec(4,1),P_rec(1,1)],[P_rec(4,2),P_rec(1,2)],'color','k','LineWidth',2);hold on;
fill(P_rec(:,1),P_rec(:,2),[0.1 0.5 0.8]);hold on;


%obs4Ϊ�����
r_star=10*0.3;

ang_star=pi*2/5;
r_star2=r_star*cos(ang_star)/cos(ang_star/2);
P_star=[0,r_star;
    r_star2*sin(0.5*ang_star),r_star2*cos(0.5*ang_star);
    r_star*sin(1*ang_star),r_star*cos(1*ang_star);
    r_star2*sin(1.5*ang_star),r_star2*cos(1.5*ang_star);
    r_star*sin(2*ang_star),r_star*cos(2*ang_star);
    r_star2*sin(2.5*ang_star),r_star2*cos(2.5*ang_star);
    r_star*sin(3*ang_star),r_star*cos(3*ang_star);
    r_star2*sin(3.5*ang_star),r_star2*cos(3.5*ang_star);
    r_star*sin(4*ang_star),r_star*cos(4*ang_star);
    r_star2*sin(4.5*ang_star),r_star2*cos(4.5*ang_star);];
P_star=P_star+[chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;];
%��obs4
for i=1:9
    plot([P_star(i,1),P_star(i+1,1)],[P_star(i,2),P_star(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_star(10,1),P_star(1,1)],[P_star(10,2),P_star(1,2)],'color','k','LineWidth',2);hold on;
fill(P_star(:,1),P_star(:,2),[0.5 0.1 0.5]);hold on;




%obs5ΪL
l_obs5=4;l_obs5_2=3;

%��obs5
P_obs5=[gao_obs5,chang_obs5;
    gao_obs5+l_obs5,chang_obs5;
    gao_obs5+l_obs5,chang_obs5+l_obs5_2/2;
    gao_obs5+l_obs5/3,chang_obs5+l_obs5_2/2;
    gao_obs5+l_obs5/3,chang_obs5+l_obs5_2*2;
    gao_obs5,chang_obs5+l_obs5_2*2;];

for i=1:5
    plot([P_obs5(i,1),P_obs5(i+1,1)],[P_obs5(i,2),P_obs5(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_obs5(6,1),P_obs5(1,1)],[P_obs5(6,2),P_obs5(1,2)],'color','k','LineWidth',2);hold on;
fill(P_obs5(:,1),P_obs5(:,2),[0.5 0.1 0.5]);hold on;


% plot(x_0.*4+chang_circle+2,y_0.*4+gao_circle,'color',[0.8 0.1 0.1]);hold on;
% 
% plot(XY2(1,:)+(gao_tri+0.5*l_tri),XY2(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),'color',[0.3 0.5 0.1]);hold on;
% 
% plot([min(P_rec(:,1))-2,min(P_rec(:,1))-2],[min(P_rec(:,2))-2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;
% plot([max(P_rec(:,1))+2,max(P_rec(:,1))+2],[min(P_rec(:,2))-2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;
% plot([min(P_rec(:,1))-2,max(P_rec(:,1))+2],[min(P_rec(:,2))-2,min(P_rec(:,2))-2],'color',[0.1 0.5 0.8]);hold on;
% plot([min(P_rec(:,1))-2,max(P_rec(:,1))+2],[max(P_rec(:,2))+2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;
% 
% plot(x_0.*(r_star+2)+chang_star,y_0.*(r_star+2)+gao_star,'color',[0.5 0.1 0.5]);hold on;
% 
% plot([min(P_obs5(:,1))-2,min(P_obs5(:,1))-2],[min(P_obs5(:,2))-2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;
% plot([max(P_obs5(:,1))+2,max(P_obs5(:,1))+2],[min(P_obs5(:,2))-2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;
% plot([min(P_obs5(:,1))-2,max(P_obs5(:,1))+2],[min(P_obs5(:,2))-2,min(P_obs5(:,2))-2],'color',[0.7 0.7 0.7]);hold on;
% plot([min(P_obs5(:,1))-2,max(P_obs5(:,1))+2],[max(P_obs5(:,2))+2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;
% 
