%%
%���10s    �ϰ������е�۵��������仯����
clc;clear all;
axis([0 40 -20 20]);theAxes=axis;
start_size=15;line_size=1.5;
L_jxb=[7.6,7.6,7.6,7.6,7.6,4,4,6];

chang_circle=5;gao_circle=-8;%O
gao_tri=30;chang_tri=4;%^
chang_rec=20;gao_rec=12;%������
chang_star=30;gao_star=-10;%�����
gao_obs5=5;chang_obs5=6;%L

for i=1:1001
    set(gca,'FontSize',16);set(gca,'FontName','Times New Roman');
    t(i)=(i-1)*0.01;
    l_tri=4;
    D_chang_circle(i)=5+9*sin(pi*t(i)/20);    D_gao_circle(i)=-10*cos(pi*t(i)/20)-2;%O
    D_gao_tri(i)=30+0.1*t(i);D_chang_tri(i)=13-1*t(i);%^
    D_chang_rec(i)=20+4*sin(pi*t(i)/5);D_gao_rec(i)=4+4*cos(pi*t(i)/5)+4*cos(pi*t(i)/20);%������
    D_chang_star(i)=35-t(i);D_gao_star(i)=-18+1.5*t(i);%�����
    D_gao_obs5(i)=5+sin(pi*t(i)/3);    D_chang_obs5(i)=11-t(i);%L
    ang_tri(i)=pi*t(i)/20;
end

 
n=101;

tic;

for j=1:n;
 %   nn=(j-1)*10+1;
    nn=(j-1)*1+900;% ���10s�Ĺ���
% [X_bez,Y_bez]=huatu(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri);

[X_bez,Y_bez,dist]=juli(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri);

DDD(j)=dist;

end
toc
% plot(X_bez(1,:),Y_bez(1,:))
% plot(DDD,'*')

plot(DDD,'color','k','LineWidth',2);hold on; 
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
% axis([1 101 8 9]); 
% set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
% set(gca,'Ytick',[8:0.2:9]);set(gca,'YtickLabel',{'400','410','420','430','440','450'});

save distance5jie.mat DDD

%%
clc;clear all;
load distance_gao_jie.mat DDD
plot(DDD,'color','k','LineWidth',2);hold on; 
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
axis([1 101 1 2]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
set(gca,'Ytick',[1:0.2:2]);set(gca,'YtickLabel',{'50','60','70','80','90','100'});
xlabel('\itt\rm(s)');
ylabel('\itd\rm(mm)');


%%
clc;clear all;
load distance5jie.mat DDD
plot(DDD,'color','k','LineWidth',2);hold on; 
set(gca,'FontName','Times New Roman');set(gca,'FontSize',16); 
axis([1 101 0 2]); 
set(gca,'Xtick',[1:10:101]);set(gca,'XtickLabel',{'90','91','92','93','94','95','96','97','98','99','100'});
set(gca,'Ytick',[0:0.5:2]);set(gca,'YtickLabel',{'0','25','50','75','100'});
xlabel('\itt\rm(s)');
ylabel('\itd\rm(mm)');


