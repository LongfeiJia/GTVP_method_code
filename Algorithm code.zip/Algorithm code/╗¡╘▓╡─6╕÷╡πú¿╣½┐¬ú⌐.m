%%
clc;clear all;
r=40;y0=12;wwe=(4*r^2-y0^2)^.5-(3^.5)*y0;
gao_x_zhou=-y0;
chang_x_zhou=0;
P_circle=[-r -y0;
    -r*sin(pi/6) -y0-r*cos(pi/6);
    r*sin(pi/6) -y0-r*cos(pi/6);
    r -y0;
    r*sin(pi/6) -y0+r*cos(pi/6);
    -r*sin(pi/6) -y0+r*cos(pi/6);
    ];

mid_circle =[0,0];

plot(mid_circle(1),mid_circle(2),'Marker','o','MarkerSize',8,'MarkerFaceColor',[0.2 0.4 0.2]);hold on;
%����ʱ�Ŵ�2������
% for i=1:6
%     P_circle_lage(i,1)=2*P_circle(i,1)-mid_circle(1);
%     P_circle_lage(i,2)=2*P_circle(i,2)-mid_circle(2);
%     plot([P_circle_lage(i,1),mid_circle(1)],[P_circle_lage(i,2),mid_circle(2)],'--','color',[0.2 0.4 0.2],'LineWidth',1);hold on;
% end

%��Բ
aplha=0:pi/40:2*pi;
x_circle=r*cos(aplha);
y_circle=r*sin(aplha)-y0;
plot(x_circle,y_circle,'color',[0.3 0.5 0.1],'LineWidth',2);hold on;
%����СԲ�ˣ����滭�Ŵ�2���Ĳ�����Բ
x_circle_lage=2.*x_circle-mid_circle(1);
y_circle_lage=2.*y_circle-mid_circle(2);
plot(x_circle_lage,y_circle_lage,'--','color','k','LineWidth',1);hold on;



P=[-1.5*(r^2-y0^2)^.5 0;
    -(r^2-y0^2)^.5 0;
    -0.25*wwe (3^.5)*wwe/4;
    0.25*wwe (3^.5)*wwe/4;
    (r^2-y0^2)^.5 0
    1.5*(r^2-y0^2)^.5 0;
    ];
P=P.*2;
for i=2:5
    plot([P(i,1),mid_circle(1)],[P(i,2),mid_circle(2)],'--','color',[0.2 0.4 0.2],'LineWidth',1);hold on;
end





[a,b]=size(P);
PP(1,:,:)=P;
for i=1:1001;
    t_plot(i)=(i-1)*0.001;    t=t_plot(i);
    aa=a;
    while (aa>0)
        aa=aa-1;
        for j=1:aa
             PP(a-aa+1,j,:)=(1-t).*PP(a-aa,j,:)+t.*PP(a-aa,j+1,:);
        end
    end
    P_end(i,:)=PP(a,1,:);
end

%fill(x_circle,y_circle,[0.3 0.5 0.1]);hold on;

for w=1:a
    plot(P(w,1),P(w,2),'Marker','o','MarkerSize',8,'MarkerFaceColor',[0 0.749 0.749]);hold on;
end
plot(P_end(:,1),P_end(:,2),'color',[0.8 0.2 0.8],'LineWidth',2);hold on;
plot([2*min(P_end(:,1))-max(P_end(:,1)),min(P_end(:,1))],[0,0],'color',[0.8 0.2 0.8],'LineWidth',2); hold on;
plot([2*max(P_end(:,1))-min(P_end(:,1)),max(P_end(:,1))],[0,0],'color',[0.8 0.2 0.8],'LineWidth',2);hold on;
ymin=0;


%����
% wwpp=(r^2-(3/4)*y0^2)^.5+0.5*y0;
wwpp=(r^2-(1/4)*y0^2)^.5+(3^.5/2)*y0;
PPP=[wwpp/2 -wwpp*(3^.5)/2;
    -wwpp/2 -wwpp*(3^.5)/2];
% for w=1:2
%     plot(PPP(w,1),PPP(w,2),'Marker','o','MarkerSize',8,'MarkerFaceColor',[0 0.749 0.749]);hold on;
% end
for i=1:2
    plot([PPP(i,1),mid_circle(1)],[PPP(i,2),mid_circle(2)],'--','color',[0.2 0.4 0.2],'LineWidth',1);hold on;
end


%����

axis([-r*3.5,r*3.5,-2*r,2*r]);
pbaspect([r*7 4*r 1])
   set(gca,'FontSize',16);set(gca,'FontName','Times New Roman');


