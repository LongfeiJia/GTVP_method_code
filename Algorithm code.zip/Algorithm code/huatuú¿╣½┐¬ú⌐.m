function [X_bez,Y_bez]=huatu(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri)

start_size=10;line_size=0.5;
%% SECTION TITLE
% DESCRIPTIVE TEXT
l_tri=4;

   
    Xobs=[];Yobs=[];    
plot([0,40],[0,0],':','color','k','LineWidth',2);hold on; 

r_0=1;
aplha=0:pi/40:2*pi;
x_0=r_0*cos(aplha);
y_0=r_0*sin(aplha);
% plot(x_0+(nn-1).*40/1000,y_0,'color','k');hold on;
% fill(x_0+(nn-1).*40/1000,y_0,[0.1 0.9 0.1]);hold on;



  plot(D_chang_circle+2,D_gao_circle,'--','color',[0.8 0.1 0.1]);hold on; 
 plot(D_gao_tri+0.5*l_tri,D_chang_tri+(1/(2*3^.5))*l_tri,'--','color',[0.3 0.5 0.1]);hold on;  
 plot(D_chang_rec,D_gao_rec,'--','color',[0.1 0.5 0.8]);hold on;  
 plot(D_chang_star,D_gao_star,'--','color',[0.5 0.1 0.5]);hold on;  
 plot(D_gao_obs5,D_chang_obs5,'--','color',[0.7 0.7 0.7]);hold on;  

chang_circle=D_chang_circle(nn);gao_circle=D_gao_circle(nn);%O
gao_tri=D_gao_tri(nn);chang_tri=D_chang_tri(nn);%^
chang_rec=D_chang_rec(nn);gao_rec=D_gao_rec(nn);%������
chang_star=D_chang_star(nn);gao_star=D_gao_star(nn);%�����
gao_obs5=D_gao_obs5(nn);chang_obs5=D_chang_obs5(nn);%L
 
 
%obs1ΪԲ
r_circle=2;

P_circle=[chang_circle gao_circle;
    chang_circle+r_circle-r_circle*sin(pi/6) gao_circle+r_circle*cos(pi/6);
    chang_circle+r_circle+r_circle*sin(pi/6) gao_circle+r_circle*cos(pi/6);
    chang_circle+2*r_circle gao_circle;
    chang_circle+r_circle+r_circle*sin(pi/6) gao_circle-r_circle*cos(pi/6);
    chang_circle+r_circle-r_circle*sin(pi/6) gao_circle-r_circle*cos(pi/6);];
%��obs1_Բ
aplha=0:pi/40:2*pi;
x_circle=r_circle*cos(aplha)+chang_circle+r_circle;
y_circle=r_circle*sin(aplha)+gao_circle;
plot(x_circle,y_circle,'color','k');hold on;
fill(x_circle,y_circle,[0.8 0.1 0.1]);hold on;

plot(x_0.*4+chang_circle+2,y_0.*4+gao_circle,'color',[0.8 0.1 0.1]);hold on;

%B ����
if abs(gao_circle)<4
    x_circle_mid=chang_circle+2;
    x_circle_1=x_circle_mid-2*(4^2-gao_circle^2)^.5;y_circle_1=0;
    x_circle_4=x_circle_mid+2*(4^2-gao_circle^2)^.5;y_circle_4=0;
    x_circle_2=x_circle_mid-2*(gao_circle*3^.5+(4*4^2-gao_circle^2)^.5)/4;y_circle_2=2*(3^.5)*(gao_circle*3^.5+(4*4^2-gao_circle^2)^.5)/4;
    x_circle_3=x_circle_mid+2*(gao_circle*3^.5+(4*4^2-gao_circle^2)^.5)/4;y_circle_3=y_circle_2;
    X_circle=[x_circle_1,x_circle_2,x_circle_3,x_circle_4];Y_circle=[y_circle_1,y_circle_2,y_circle_3,y_circle_4];
    for circle_i=1:4
         plot(X_circle(circle_i),Y_circle(circle_i),'*','color',[0.8 0.1 0.1],'MarkerSize',start_size,'LineWidth',line_size);hold on;
    end
    Xobs=[Xobs,X_circle];Yobs=[Yobs,Y_circle];
end

%obs2Ϊ������

%��obs2
P1_tri=[gao_tri,chang_tri];
P2_tri=[gao_tri+l_tri,chang_tri];
P3_tri=[gao_tri+0.5*l_tri,chang_tri+(3^.5/2)*l_tri];
x_tri=[P1_tri(1),P2_tri(1),P3_tri(1),P1_tri(1)];
y_tri=[P1_tri(2),P2_tri(2),P3_tri(2),P1_tri(2)];

x_tri2=[P1_tri(1)-2*3^.5,P2_tri(1)+2*3^.5,P3_tri(1),P1_tri(1)-2*3^.5];
y_tri2=[P1_tri(2)-2,P2_tri(2)-2,P3_tri(2)+4,P1_tri(2)-2];

ang=ang_tri(nn);
Rz=[cos(ang) -sin(ang);sin(ang) cos(ang);];
for w=1:4
    XY(:,w)=Rz*[x_tri(w)-(gao_tri+0.5*l_tri);y_tri(w)-(chang_tri+(1/(2*3^.5))*l_tri)];
    XY2(:,w)=Rz*[x_tri2(w)-(gao_tri+0.5*l_tri);y_tri2(w)-(chang_tri+(1/(2*3^.5))*l_tri)];
end
plot(XY(1,:)+(gao_tri+0.5*l_tri),XY(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),'color','k');hold on;
fill(XY(1,:)+(gao_tri+0.5*l_tri),XY(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),[0.3 0.5 0.1]);hold on;

plot(XY2(1,:)+(gao_tri+0.5*l_tri),XY2(2,:)+(chang_tri+(1/(2*3^.5))*l_tri),'color',[0.3 0.5 0.1]);hold on;
%B ����
if min(XY2(2,:))+(chang_tri+(1/(2*3^.5))*l_tri)<0
    tri1=[XY2(1,1)+(gao_tri+0.5*l_tri),XY2(2,1)+(chang_tri+(1/(2*3^.5))*l_tri)];
    tri2=[XY2(1,2)+(gao_tri+0.5*l_tri),XY2(2,2)+(chang_tri+(1/(2*3^.5))*l_tri)];
    tri3=[XY2(1,3)+(gao_tri+0.5*l_tri),XY2(2,3)+(chang_tri+(1/(2*3^.5))*l_tri)];
    if tri1(2)<0
        tri=tri1;
        tri1=tri3;
        tri3=tri;
    end
    if tri2(2)<0
        tri=tri2;
        tri2=tri3;
        tri3=tri;
    end
    x_tri_1=tri3(1)-tri3(2)*(tri3(1)-tri1(1))/(tri3(2)-tri1(2));
    x_tri_2=tri2(1)-tri2(2)*(tri2(1)-tri3(1))/(tri2(2)-tri3(2));
    mid_P_tri=(x_tri_1+x_tri_2)/2;
    x_t_1=2*x_tri_1-mid_P_tri;y_tri_1=0;
    x_t_2=2*x_tri_2-mid_P_tri;y_tri_2=0;
    x_t_3=2*tri3(1)-mid_P_tri;y_tri_3=2*tri3(2);
%        x_t_1=x_tri_1;y_tri_1=0;
%     x_t_2=x_tri_2;y_tri_2=0;
%     x_t_3=tri3(1);y_tri_3=2*tri3(2); 
    X_tri=[x_t_1,x_t_3,x_t_2];Y_tri=[y_tri_1,y_tri_3,y_tri_2];
    for tri_i=1:3
         plot(X_tri(tri_i),Y_tri(tri_i),'*','color',[0.3 0.5 0.1],'MarkerSize',start_size,'LineWidth',line_size);hold on;
    end
    Xobs=[Xobs,X_tri];Yobs=[Yobs,Y_tri];
end


%obs3Ϊ������
chang=4;
gao=6;

P_rec=[chang_rec gao_rec;
    chang_rec gao_rec+gao;
    chang_rec+chang gao_rec+gao;
    chang_rec+chang gao_rec];
%��obs3
for i=1:3
    plot([P_rec(i,1),P_rec(i+1,1)],[P_rec(i,2),P_rec(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_rec(4,1),P_rec(1,1)],[P_rec(4,2),P_rec(1,2)],'color','k','LineWidth',2);hold on;
fill(P_rec(:,1),P_rec(:,2),[0.1 0.5 0.8]);hold on;

plot([min(P_rec(:,1))-2,min(P_rec(:,1))-2],[min(P_rec(:,2))-2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;
plot([max(P_rec(:,1))+2,max(P_rec(:,1))+2],[min(P_rec(:,2))-2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;
plot([min(P_rec(:,1))-2,max(P_rec(:,1))+2],[min(P_rec(:,2))-2,min(P_rec(:,2))-2],'color',[0.1 0.5 0.8]);hold on;
plot([min(P_rec(:,1))-2,max(P_rec(:,1))+2],[max(P_rec(:,2))+2,max(P_rec(:,2))+2],'color',[0.1 0.5 0.8]);hold on;

%B ����
if min(P_rec(:,2))<2
    min_P_rec=min(P_rec(:,2))-2;
    x_rec_mid=chang_rec+chang/2;
    x_rec_1=2*chang_rec-x_rec_mid;y_rec_1=0;
    x_rec_4=2*(chang_rec+chang)-x_rec_mid;y_rec_4=0;
    x_rec_2=x_rec_mid-2*min_P_rec/(3^.5);y_rec_2=2*min_P_rec;
    x_rec_3=x_rec_mid+2*min_P_rec/(3^.5);y_rec_3=y_rec_2;
    X_rec=[x_rec_1,x_rec_2,x_rec_3,x_rec_4];Y_rec=[y_rec_1,y_rec_2,y_rec_3,y_rec_4];
    for rec_i=1:4
         plot(X_rec(rec_i),Y_rec(rec_i),'*','color',[0.1 0.5 0.8],'MarkerSize',start_size,'LineWidth',line_size);hold on;
    end
    Xobs=[Xobs,X_rec];Yobs=[Yobs,Y_rec];
end


%obs4Ϊ�����
r_star=10*0.3;

ang_star=pi*2/5;
r_star2=r_star*cos(ang_star)/cos(ang_star/2);
P_star=[0,r_star;
    r_star2*sin(0.5*ang_star),r_star2*cos(0.5*ang_star);
    r_star*sin(1*ang_star),r_star*cos(1*ang_star);
    r_star2*sin(1.5*ang_star),r_star2*cos(1.5*ang_star);
    r_star*sin(2*ang_star),r_star*cos(2*ang_star);
    r_star2*sin(2.5*ang_star),r_star2*cos(2.5*ang_star);
    r_star*sin(3*ang_star),r_star*cos(3*ang_star);
    r_star2*sin(3.5*ang_star),r_star2*cos(3.5*ang_star);
    r_star*sin(4*ang_star),r_star*cos(4*ang_star);
    r_star2*sin(4.5*ang_star),r_star2*cos(4.5*ang_star);];
P_star=P_star+[chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;chang_star,gao_star;];
%��obs4
for i=1:9
    plot([P_star(i,1),P_star(i+1,1)],[P_star(i,2),P_star(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_star(10,1),P_star(1,1)],[P_star(10,2),P_star(1,2)],'color','k','LineWidth',2);hold on;
fill(P_star(:,1),P_star(:,2),[0.5 0.1 0.5]);hold on;

plot(x_0.*(r_star+2)+chang_star,y_0.*(r_star+2)+gao_star,'color',[0.5 0.1 0.5]);hold on;

%B ����
if abs(gao_star)<(r_star+2)
    rr=(r_star+2);
    x_star_mid=chang_star;
    x_star_1=x_star_mid-2*(rr^2-gao_star^2)^.5;y_star_1=0;
    x_star_4=x_star_mid+2*(rr^2-gao_star^2)^.5;y_star_4=0;
    x_star_2=x_star_mid-2*(gao_star*3^.5+(4*rr^2-gao_star^2)^.5)/4;y_star_2=2*(3^.5)*(gao_star*3^.5+(4*rr^2-gao_star^2)^.5)/4;
    x_star_3=x_star_mid+2*(gao_star*3^.5+(4*rr^2-gao_star^2)^.5)/4;y_star_3=y_star_2;
    X_star=[x_star_1,x_star_2,x_star_3,x_star_4];Y_star=[y_star_1,y_star_2,y_star_3,y_star_4];
    for star_i=1:4
         plot(X_star(star_i),Y_star(star_i),'*','color',[0.5 0.1 0.5],'MarkerSize',start_size,'LineWidth',line_size);hold on;
    end
    Xobs=[Xobs,X_star];Yobs=[Yobs,Y_star];
end


%obs5ΪL
l_obs5=4;l_obs5_2=3;

%��obs5
P_obs5=[gao_obs5,chang_obs5;
    gao_obs5+l_obs5,chang_obs5;
    gao_obs5+l_obs5,chang_obs5+l_obs5_2/2;
    gao_obs5+l_obs5/3,chang_obs5+l_obs5_2/2;
    gao_obs5+l_obs5/3,chang_obs5+l_obs5_2*2;
    gao_obs5,chang_obs5+l_obs5_2*2;];

for i=1:5
    plot([P_obs5(i,1),P_obs5(i+1,1)],[P_obs5(i,2),P_obs5(i+1,2)],'color',[0 0 0],'LineWidth',2);hold on;
end
plot([P_obs5(6,1),P_obs5(1,1)],[P_obs5(6,2),P_obs5(1,2)],'color',[0 0 0],'LineWidth',2);hold on;
fill(P_obs5(:,1),P_obs5(:,2),[0.7 0.7 0.7]);hold on;

plot([min(P_obs5(:,1))-2,min(P_obs5(:,1))-2],[min(P_obs5(:,2))-2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;
plot([max(P_obs5(:,1))+2,max(P_obs5(:,1))+2],[min(P_obs5(:,2))-2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;
plot([min(P_obs5(:,1))-2,max(P_obs5(:,1))+2],[min(P_obs5(:,2))-2,min(P_obs5(:,2))-2],'color',[0.7 0.7 0.7]);hold on;
plot([min(P_obs5(:,1))-2,max(P_obs5(:,1))+2],[max(P_obs5(:,2))+2,max(P_obs5(:,2))+2],'color',[0.7 0.7 0.7]);hold on;

%B ����
if min(P_obs5(:,2))<2
    min_P_obs5=min(P_obs5(:,2))-2;
    x_obs5_mid=gao_obs5+l_obs5/2;
    x_obs5_1=2*(gao_obs5-2)-x_obs5_mid;y_obs5_1=0;
    x_obs5_4=2*(gao_obs5+2+l_obs5)-x_obs5_mid;y_obs5_4=0;
    x_obs5_2=x_obs5_mid-2*min_P_obs5/(3^.5);y_obs5_2=2*min_P_obs5;
    x_obs5_3=x_obs5_mid+2*min_P_obs5/(3^.5);y_obs5_3=y_obs5_2;
    X_obs5=[x_obs5_1,x_obs5_2,x_obs5_3,x_obs5_4];Y_obs5=[y_obs5_1,y_obs5_2,y_obs5_3,y_obs5_4];
    for obs5_i=1:4
         plot(X_obs5(obs5_i),Y_obs5(obs5_i),'*','color',[0.1 0.5 0.8],'MarkerSize',start_size,'LineWidth',line_size);hold on;
    end
    Xobs=[Xobs,X_obs5];Yobs=[Yobs,Y_obs5];
end

%���� ����   �ϵĵ�
if ~isempty(Xobs)
    [a b]=size(Xobs);
    for ai=1:b-1
        for bj=ai+1:b
            if Xobs(bj)<Xobs(ai)
                ox=Xobs(bj);oy=Yobs(bj);
                Xobs(bj)=Xobs(ai);Yobs(bj)=Yobs(ai);
                Xobs(ai)=ox;Yobs(ai)=oy;
            end
        end
    end
num=1;    
for ai=1:b
    if Xobs(ai)>0
        XYO(1,num)=Xobs(ai);XYO(2,num)=Yobs(ai);
        num=num+1;
    end
end
X=[0,2,XYO(1,:),38,40];
Y=[0,0,XYO(2,:),0,0];

[X_bez,Y_bez]=bezier(X,Y);
plot(X_bez,Y_bez,'color',[0.8 0.2 0.8],'LineWidth',2);hold on;

% [P,S]=polyfit(X,Y,3);
% plot(X,Y,'k*',X,polyval(P,X),'k-')

%     interp1(XYO(1,:),XYO(2,:),'spline'); 




     
end