function [X,Y]=bezierN(x,y)
n=length(x);
% n=5;
t=linspace(0,1,100000);
xx=0;yy=0;
for k=0:n-1
    tmp=nchoosek(n-1,k)*t.^k.*(1-t).^(n-1-k);
    xx=xx+tmp*x(k+1);
    yy=yy+tmp*y(k+1);
end
if nargout==2
    X=xx;Y=yy;
end
if nargout==1
    X=h;
end