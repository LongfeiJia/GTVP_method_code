function link(x_init,y_init,x_end,y_end)
d=((x_init-x_end)^2+(y_init-y_end)^2)^.5;
l=0.5;ll=0.4;
k=(y_init-y_end)/(x_init-x_end+0.00000001);
plot([x_init,x_init+l/((1+k^2)^.5)],[y_init,y_init+k*l/((1+k^2)^.5)],'color','k','LineWidth',2);hold on;
plot([x_end,x_end-l/((1+k^2)^.5)],[y_end,y_end-k*l/((1+k^2)^.5)],'color','k','LineWidth',2);hold on;

r_0=0.2;
aplha=0:pi/40:2*pi;
x_0=r_0*cos(aplha);
y_0=r_0*sin(aplha);
plot(x_0+x_init,y_0+y_init,'color','k');hold on;
fill(x_0+x_init,y_0+y_init,[0.9 0.9 0.9]);hold on;
plot(x_0+x_end,y_0+y_end,'color','k');hold on;
fill(x_0+x_end,y_0+y_end,[0.9 0.9 0.9]);hold on;

if k==0
    P_rec=[x_init+l,y_init+ll;
        x_end-l,y_end+ll;
        x_end-l,y_end-ll;
    x_init+l,y_init-ll;
    ];
else
P_rec=[x_init+l/((1+k^2)^.5)+ll/((1+1/k^2)^.5),y_init+k*l/((1+k^2)^.5)+(-1/k)*ll/((1+1/k^2)^.5);
    x_end-l/((1+k^2)^.5)+ll/((1+1/k^2)^.5),y_end-k*l/((1+k^2)^.5)+(-1/k)*ll/((1+1/k^2)^.5);
    x_end-l/((1+k^2)^.5)-ll/((1+1/k^2)^.5),y_end-k*l/((1+k^2)^.5)-(-1/k)*ll/((1+1/k^2)^.5);
    x_init+l/((1+k^2)^.5)-ll/((1+1/k^2)^.5),y_init+k*l/((1+k^2)^.5)-(-1/k)*ll/((1+1/k^2)^.5);];
end


for i=1:3
    plot([P_rec(i,1),P_rec(i+1,1)],[P_rec(i,2),P_rec(i+1,2)],'color','k','LineWidth',2);hold on;
end
plot([P_rec(4,1),P_rec(1,1)],[P_rec(4,2),P_rec(1,2)],'color','k','LineWidth',2);hold on;
fill(P_rec(:,1),P_rec(:,2),[0.9 0.9 0.9]);hold on;

