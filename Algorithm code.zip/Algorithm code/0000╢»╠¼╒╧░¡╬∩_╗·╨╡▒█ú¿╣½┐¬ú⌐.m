%%
%��̬�ϰ���
clc;clear all;
hold off;
axis([0 40 -20 20]);theAxes=axis;
start_size=15;line_size=1.5;
L_jxb=[7.6,7.6,7.6,7.6,7.6,4,4,6];

chang_circle=5;gao_circle=-8;%O
gao_tri=30;chang_tri=4;%^
chang_rec=20;gao_rec=12;%������
chang_star=30;gao_star=-10;%�����
gao_obs5=5;chang_obs5=6;%L

for i=1:1001
    set(gca,'FontSize',16);set(gca,'FontName','Times New Roman');
    t(i)=(i-1)*0.01;
    l_tri=4;
    D_chang_circle(i)=5+9*sin(pi*t(i)/20);    D_gao_circle(i)=-10*cos(pi*t(i)/20)-2;%O
    D_gao_tri(i)=30+0.1*t(i);D_chang_tri(i)=13-1*t(i);%^
    D_chang_rec(i)=20+4*sin(pi*t(i)/5);D_gao_rec(i)=4+4*cos(pi*t(i)/5)+4*cos(pi*t(i)/20);%������
    D_chang_star(i)=35-t(i);D_gao_star(i)=-18+1.5*t(i);%�����
    D_gao_obs5(i)=5+sin(pi*t(i)/3);    D_chang_obs5(i)=11-t(i);%L
    ang_tri(i)=pi*t(i)/20;
end

 
n=101;
%n=1001;
fmat=moviein(n);


for j=1:n;
   % nn=(j-1)*10+1;
    nn=(j-1)*1+900;% ���10s�Ĺ���
   % nn=(j);
    [X_bez,Y_bez]=huatu(nn,D_chang_circle,D_gao_circle,D_gao_tri,D_chang_tri,D_chang_rec,D_gao_rec,D_chang_star,D_gao_star,D_gao_obs5,D_chang_obs5,ang_tri);
    
    huatu_manipulator(nn,X_bez,Y_bez,L_jxb);
%  plot(X_bez(1,:),Y_bez(1,:))

set(gca,'Xtick',[0:5:40]);set(gca,'XtickLabel',{'0','250 ','500','750','1000','1250','1500','1750','2000'});
set(gca,'Ytick',[-20:5:20]);set(gca,'YtickLabel',{'-1000','-750','-500','-250 ','0','250','500','750','1000'});


% set(gca,'xtick',[0 150 300 450 600 750 900 1050 1200 1350]);set(gca,'xticklabel',{'0' 'L' '2L' '3L' '4L' '5L' '6L' '7L' '8L' '9L'});
    set(gca,'FontName','Times New Roman');set(gca,'FontSize',16);    
    set(0,'defaultfigurecolor','w');axis([0 40 -20 20]); pbaspect([1 1 1])
    box('on');
    
hold off;
axis(theAxes)
fmat(:,j)=getframe;      F=getframe(gca);     imind=frame2im(F);
    [imind,cm]=rgb2ind(imind,256);
    if j==1
        imwrite(imind,cm,'c1.gif','GIF','Loopcount',inf,'DelayTime',0.1);
    else
        imwrite(imind,cm,'c1.gif','GIF','WriteMode','append','DelayTime',0.1);
    end
 hold off;
end
