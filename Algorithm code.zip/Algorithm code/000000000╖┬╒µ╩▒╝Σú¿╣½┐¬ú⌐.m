%%
clc;clear all;
X=1:1:5;
Y=[0,1,3,1,0];

tic;
for i=1:1001
    [Xoo,Yoo]=bezier(X,Y);
end
toc


%18.674207

%%
clc;clear all;
X=1:1:6;
Y=[0,1,3,3,1,0];

tic;
for i=1:1001
    [Xoo,Yoo]=bezier(X,Y);
end

toc
%27.928456

%%
clc;clear all;
X=1:1:8;
Y=[0,1,3,6,6,3,1,0];

tic;
for i=1:1001
    [Xoo,Yoo]=bezier(X,Y);
end
toc
%44.491427
%%
clc;clear all;
X=1:1:10;
Y=[0,1,3,6,8,8,6,3,1,0];

tic;
for i=1:1001
    [Xoo,Yoo]=bezier(X,Y);
end
toc
%60.552415