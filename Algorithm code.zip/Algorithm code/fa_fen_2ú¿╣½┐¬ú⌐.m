function [x,y]=fa_fen_2(x_jxb,y_jxb,L,X_bez,Y_bez)
[a,b]=size(X_bez);

x=X_bez(1);y=Y_bez(1);
e=abs((x-x_jxb)^2+(y-y_jxb)^2-L^2);
emin=e;
for j=2:b
    if X_bez(j)<x_jxb
        e=abs((X_bez(j)-x_jxb)^2+(Y_bez(j)-y_jxb)^2-L^2);
        if e<emin
            emin=e;
            x=X_bez(j);y=Y_bez(j);
        end
    end
end

% e=(x-x_jxb)^2+(y-y_jxb)^2-L^2;
% x1=X_bez(j-1);y1=Y_bez(j-1);
% if j==100
%     x2=X_bez(j);y2=Y_bez(j);
% else
%       x2=X_bez(j+1);y2=Y_bez(j+1);
% end
% 
% while abs(e)>1
%     x3=(x1+x2)/2;y3=(y1+y2)/2;
%     e=(x3-x_jxb)^2+(y3-y_jxb)^2-L^2;
%     if e>0
%         x1=x3;y1=y3;
%     else
%         x2=x3;y2=y3;
%     end
% end
% x=(x1+x2)/2;y=(y1+y2)/2;
