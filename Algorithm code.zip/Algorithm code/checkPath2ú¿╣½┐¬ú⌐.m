function feasible=checkPath2(n,newPos,map,stepsize,theta)
L=486;
feasible=true;
dir=atan2(newPos(1)-n(1),newPos(2)-n(2));
nn=n(1:2);
ang=n(4);
for r=0:0.5:sqrt(sum((nn-newPos).^2))
    posCheck=nn+r.*[sin(dir) cos(dir)];
    if ~(feasiblePoint(ceil(posCheck),map) && feasiblePoint(floor(posCheck),map) && ...
            feasiblePoint([ceil(posCheck(1)) floor(posCheck(2))],map) && feasiblePoint([floor(posCheck(1)) ceil(posCheck(2))],map))
        feasible=false;break;
    end
    if ~feasiblePoint(newPos,map), feasible=false; end
end
% a=20*pi/(asin(stepsize*sin(pi/9)/L)*180);
% maxang=(20/a)*pi/180;
% 
% if (abs(theta-ang)>maxang)&(ang~=0.001)
%     feasible=false;
% end