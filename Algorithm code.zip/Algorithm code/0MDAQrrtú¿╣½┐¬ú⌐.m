clc;clear all;

map=im2bw(imread('100.png'));


source=[315 180]; % source position in Y, X format570-150=420
goal=[315 690]; % goal position in Y, X format
stepsize =30;  % size of each step of the RRT
threshold = 20; % nodes closer than this threshold are taken as almost the same

rstepsize=1.5*stepsize;
maxFailedAttempts = 10000000;
display = true; 


if ~feasiblePoint(source,map), error('source lies on an obstacle or outside map'); end
if ~feasiblePoint(goal,map), error('goal lies on an obstacle or outside map'); end
if display,imshow(map);
    %rectangle('position',[1 1 size(map)-1],'edgecolor','k'); 
end

 
RRTree = double([source -1 0.001 0]); % RRT rooted at the source, representation node and parent index
failedAttempts = 0;
counter = 0;
pathFound = false;
 tic;  % tic-toc: Functions for Elapsed Time
while failedAttempts <= maxFailedAttempts  % loop to grow RRTs
% chooses a random configuration
    if rand < 0.9
        sample = rand(1,2) .* size(map);   % random sample
    else
        sample = goal; % sample taken as goal to bias tree generation to goal
    end

    [A, I] = min( distanceCost(RRTree(:,1:2),sample) ,[],1); % find the minimum value of each column
    closestNode = RRTree(I(1),1:4);
     
    theta = atan2(sample(1)-closestNode(1),sample(2)-closestNode(2));  % direction to extend sample to produce new node
  ang=closestNode(4);
  dfg=((closestNode(1)-goal(1))^2+(closestNode(2)-goal(2))^2)^0.5;
if dfg<(206+284)
maxang=(40)*pi/180;
  else
 maxang=(22.4)*pi/180;
  end
 
    if (abs(theta-ang)>maxang)&(ang~=0.001)
       theta = (ang+sign(theta-ang)*maxang);
    end
    if (ang==0.001)
      theta =(rand*2-1)*pi/3;
   end
    
    newPoint = double(int32(closestNode(1:2) + stepsize * [sin(theta)  cos(theta)]));
    if ~checkPath2(closestNode(1:4), newPoint, map,stepsize,theta ) % if extension of closest node in tree to the new point is feasible
        failedAttempts = failedAttempts + 1;
        continue;
    end
    
    if ((distanceCost(newPoint,goal) < stepsize) &(acos(((goal(1)-newPoint(1))*(newPoint(1)-closestNode(1))+(goal(2)-newPoint(2))*(newPoint(2)-closestNode(2)))/(stepsize*(((goal(1)-newPoint(1))^2+(goal(2)-newPoint(2))^2)^0.5)))<maxang))|(distanceCost(newPoint,goal) <10)
        pathFound = true; 
        break; 
    end % goal reached
     
    [A, I2] = min( distanceCost(RRTree(:,1:2),newPoint) ,[],1); % check if new node is not already pre-existing in the tree
    if distanceCost(newPoint,RRTree(I2(1),1:2)) < threshold, failedAttempts = failedAttempts + 1; continue; end
     
    [ajl bjl]=size(RRTree);
for ijl=1:ajl
    thetai=acos((newPoint(2)-RRTree(ijl,2))/((newPoint(2)-RRTree(ijl,2))^2+(newPoint(1)-RRTree(ijl,1))^2)^0.5);
     if (abs(thetai-RRTree(ijl,4))<(22.4)*pi/180)&(checkPath2(RRTree(ijl,1:4), newPoint, map,stepsize,thetai))
         if ((RRTree(I(1),5)+distanceCost(newPoint,RRTree(I(1),1:2)))>RRTree(ijl,5)+distanceCost(newPoint,RRTree(ijl,1:2)))
             I(1)=ijl; closestNode=RRTree(I(1),1:2);theta=thetai;
             line([RRTree(ijl,2);newPoint(2)],[RRTree(ijl,1);newPoint(1)], 'Color',[0.3 0.8 0.8],'LineWidth',1);hold on;
         end
     end
end  

for ijl=1:ajl
     if (distanceCost(newPoint,RRTree(ijl,1:2)) <2.5*stepsize)
        prev1 = I(1);
while prev1 > 0
    if checkPath2(RRTree(prev1,1:4),RRTree(ijl,1:2), map,stepsize,theta)& (prev1~=ijl)&(RRTree(ijl,5)>RRTree(prev1,5)+distanceCost(RRTree(ijl,1:2),RRTree(prev1,1:2))) %%!!!!!!!!!!!!!!!jiaodu
        if abs(acos((RRTree(ijl,2)-RRTree(prev1,2))/(((RRTree(ijl,2)-RRTree(prev1,2))^2+(RRTree(ijl,1)-RRTree(prev1,1))^2)^0.5))-RRTree(prev1,4)) <22.4*pi/180
            RRTree(ijl,5)=RRTree(prev1,5)+distanceCost(RRTree(ijl,1:2),RRTree(prev1,1:2));
            RRTree(ijl,3)=prev1; RRTree(ijl,4)=acos((RRTree(ijl,2)-RRTree(prev1,2))/(((RRTree(ijl,2)-RRTree(prev1,2))^2+(RRTree(ijl,1)-RRTree(prev1,1))^2)^0.5));
             line([RRTree(ijl,2);RRTree(prev1,2)],[RRTree(ijl,1);RRTree(prev1,1)], 'Color',[1 0.7 0.3],'LineWidth',1);hold on;
        end
    end
    prev1 = RRTree(prev1,3);
end
  
     end
end  

    
    ddd=distanceCost(newPoint,RRTree(I(1),1:2));
  RRTree = [RRTree; newPoint I(1) theta ddd+RRTree(I(1),5)];

    failedAttempts = 0;
    if display, line([closestNode(2);newPoint(2)],[closestNode(1);newPoint(1)]);hold on;counter = counter + 1; M(counter) = getframe; end % Capture movie frame
end

if display && pathFound, line([closestNode(2);newPoint(2)],[closestNode(1);newPoint(1)]);hold on;line([newPoint(2);goal(2)],[newPoint(1);goal(1)]);hold on; counter = counter+1;M(counter) = getframe; end
 
if display, disp('click/press any key'); waitforbuttonpress; end
if ~pathFound, error('no path found. maximum attempts reached'); end
 
% retrieve path from parent information
path = [newPoint;goal];
prev = I(1);
while prev > 0
    path = [RRTree(prev,1:2); path];
    prev = RRTree(prev,3);
end
 
pathLength = 0;
for i=1:length(path)-1, pathLength = pathLength + distanceCost(path(i,1:2),path(i+1,1:2)); end % calculate path length
fprintf('processing time=%d \nPath Length=%d \n\n', toc, pathLength);
%imshow(map);%rectangle('position',[1 1 size(map)-1],'edgecolor','k');
 line(path(:,2),path(:,1), 'Color',[1 0 0],'LineWidth',2);hold on;
%  line([2*path(1,2)-path(2,2) path(1,2)],[2*path(1,1)-path(2,1) path(1,1)], 'LineStyle','--', 'Color',[1 0 0],'LineWidth',1);hold on;
glh=5;
line([source(2)-glh;source(2)+glh],[source(1);source(1)], 'Color',[0 1 0],'LineWidth',2);hold on;
line([source(2);source(2)],[source(1)-glh;source(1)+glh], 'Color',[0 1 0],'LineWidth',2);hold on;

line([goal(2)-glh;goal(2)+glh],[goal(1);goal(1)], 'Color',[0 1 0],'LineWidth',2);hold on;
line([goal(2);goal(2)],[goal(1)-glh;goal(1)+glh], 'Color',[0 1 0],'LineWidth',2);hold on;


save path.mat  path source goal