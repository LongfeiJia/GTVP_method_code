%%
%3�ױ���������
clc;clear all;
r=4;
gao_x_zhou=-3;
chang_x_zhou=5;
% P_circle=[chang_x_zhou gao_x_zhou;chang_x_zhou+r gao_x_zhou+r;chang_x_zhou+2*r gao_x_zhou;chang_x_zhou+r gao_x_zhou-r];
P_circle=[chang_x_zhou gao_x_zhou;
    chang_x_zhou+r-r*sin(pi/6) gao_x_zhou+r*cos(pi/6);
    chang_x_zhou+r+r*sin(pi/6) gao_x_zhou+r*cos(pi/6);
    chang_x_zhou+2*r gao_x_zhou;
    chang_x_zhou+r+r*sin(pi/6) gao_x_zhou-r*cos(pi/6);
    chang_x_zhou+r-r*sin(pi/6) gao_x_zhou-r*cos(pi/6);];



mid_circle =[chang_x_zhou+r,0];

plot(mid_circle(1),mid_circle(2),'Marker','o','MarkerSize',8,'MarkerFaceColor',[0.2 0.4 0.2]);hold on;
%����ʱ�Ŵ�2������
for i=1:4
    P_circle_lage(i,1)=2*P_circle(i,1)-mid_circle(1);
    P_circle_lage(i,2)=2*P_circle(i,2)-mid_circle(2);
    plot([P_circle_lage(i,1),mid_circle(1)],[P_circle_lage(i,2),mid_circle(2)],'--','color',[0.2 0.4 0.2],'LineWidth',1);hold on;
end

%��Բ
aplha=0:pi/40:2*pi;
x_circle=r*cos(aplha)+chang_x_zhou+r;
y_circle=r*sin(aplha)+gao_x_zhou;
plot(x_circle,y_circle,'-');hold on;
%����СԲ�ˣ����滭�Ŵ�2���Ĳ�����Բ
x_circle_lage=2.*x_circle-mid_circle(1);
y_circle_lage=2.*y_circle-mid_circle(2);
plot(x_circle_lage,y_circle_lage,'-');hold on;




P=[min(P_circle_lage(:,1))-2*r 0;
    min(P_circle_lage(:,1)) 0;
    P_circle_lage(2,1) P_circle_lage(2,2);
    P_circle_lage(3,1) P_circle_lage(3,2);
    max(P_circle_lage(:,1)) 0;
    max(P_circle_lage(:,1))+2*r 0];

[a,b]=size(P);
PP(1,:,:)=P;
for i=1:1001;
    t_plot(i)=(i-1)*0.001;    t=t_plot(i);
    aa=a;
    while (aa>0)
        aa=aa-1;
        for j=1:aa
             PP(a-aa+1,j,:)=(1-t).*PP(a-aa,j,:)+t.*PP(a-aa,j+1,:);
        end
    end
    P_end(i,:)=PP(a,1,:);
end

fill(x_circle,y_circle,[0.3 0.5 0.1]);hold on;

for w=1:a
    plot(P(w,1),P(w,2),'Marker','o','MarkerSize',8,'MarkerFaceColor',[0 0.749 0.749]);hold on;
end
plot(P_end(:,1),P_end(:,2),'color',[0.8 0.2 0.8],'LineWidth',2);hold on;
plot([2*min(P_end(:,1))-max(P_end(:,1)),min(P_end(:,1))],[0,0],'color',[0.8 0.2 0.8],'LineWidth',2); hold on;
plot([2*max(P_end(:,1))-min(P_end(:,1)),max(P_end(:,1))],[0,0],'color',[0.8 0.2 0.8],'LineWidth',2);hold on;
ymin=0;

axis([min(P_circle_lage(:,1))-r*2.5,max(P_circle_lage(:,1))+r*2.5,ymin-r,max(P_circle_lage(:,2))+r]);
pbaspect([max(P_circle_lage(:,1))+r*5-min(P_circle_lage(:,1)) max(P_circle_lage(:,2))+r-ymin+r 1])
   set(gca,'FontSize',16);set(gca,'FontName','Times New Roman');

